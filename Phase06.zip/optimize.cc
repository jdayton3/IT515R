#include <cmath>
#include <cstdlib>
#include <iostream>
#include <vector>

size_t const ROWS = 1024u;
size_t const COLUMNS = 1024u;
float const EPSILON = 0.01f;

using Grid = std::vector<std::vector<float>>;


float calculate_next(Grid & from) {
    Grid to{from};
    float error = 0.0f;
    for (size_t row = 1; row < ROWS - 1; ++row) {
        for (size_t column = 1; column < COLUMNS; ++column) {
            float average = (
                  from[row - 1][column]
                + from[row + 1][column]
                + from[row][column - 1]
                + from[row][column + 1]
            ) / 4.0f;
	    to[row][column] = average;
	    error = std::max(error, std::abs(average - from[row][column]));
        }
    }
    from = to;
    return error;
}

void initialize(Grid & grid) {
    for (auto & row : grid) {
        row[0] = 0.0f;
        row[COLUMNS - 1] = 0.0f;
    }

    for (auto & column : grid[0]) {
        column = 0.0f;
    }

    for (auto & column : grid[ROWS - 1]) {
        column = 0.0f;
    }
}

int main(void) {
    std::vector<std::vector<float>> grid(ROWS, std::vector<float>(COLUMNS, 50.0f));

    initialize(grid);

    uint32_t iterations = 0;
    while (EPSILON < calculate_next(grid)) {
        iterations += 1;
    }

    std::cout << iterations << std::endl;

    return 0;
}

